export const ADD_USER = 'ADD_USER';
export const ADD_CHAT_ROOM = 'ADD_CHAT_ROOM';